// src/Layout.jsx
import Navbar from "./Components/Navbar";
import Footer from "./Components/Footer";

const Layout = ({ children }) => {
  return (
    <div > 
     
      <Navbar />
      <main className="px-4 sm:px-8 md:px-16 lg:px-[100px] pt-[50px]">{children}</main>
      <Footer />
    </div>
  );
};

export default Layout;
