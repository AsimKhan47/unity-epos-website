import React, { useState } from "react";

const CustomerReviews = () => {
  const [visibleCount, setVisibleCount] = useState(6);

  // Dummy reviews array
  const allReviews = Array(9).fill({
    stars: 5,
    text: "“The AI Voice Agent cut our call handling time in half. Customers love the faster response, and our staff can focus on service.”",
    author: "Mark K.",
    avatar: "https://i.pravatar.cc/40?img=3",
  });

  const showMoreReviews = () => {
    setVisibleCount((prev) => prev + 6);
  };

  return (
    <div className="relative bg-gradient-to-b from-[#E1F1F0] to-[#E1F1F000] px-4 sm:px-8 md:px-12 lg:px-[100px] py-10 rounded-3xl shadow-md -mx-4 sm:-mx-8 md:-mx-16 lg:-mx-[100px] overflow-hidden">
      {/* Section Heading */}
      <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-[72px] font-bold text-center mb-10 leading-tight">
        <span className="bg-gradient-to-r from-[#00C9B3] to-[#00645A] bg-clip-text text-transparent">
          Voices
        </span>{" "}
        <span className="text-gray-800">of Our Customers</span>
      </h2>

      {/* Reviews Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {allReviews.slice(0, visibleCount).map((review, index) => (
          <div
            key={index}
            className={`bg-white p-6 rounded-xl shadow hover:shadow-lg transition duration-200 flex flex-col h-full
              ${index % 3 === 1 ? "lg:-mt-6" : ""} // only stagger on desktop
            `}
          >
            {/* Stars */}
            <div className="text-teal-600 text-base sm:text-lg mb-3">
              {"★".repeat(review.stars)}{"☆".repeat(5 - review.stars)}
            </div>

            {/* Review Text */}
            <p className="text-gray-700 mb-6 flex-grow leading-relaxed text-sm sm:text-base">
              {review.text}
            </p>

            {/* Author */}
            <div className="flex items-center gap-3">
              <img
                src={review.avatar}
                alt={review.author}
                className="w-8 h-8 sm:w-10 sm:h-10 rounded-full"
              />
              <div className="text-xs sm:text-sm font-semibold text-gray-700">
                — {review.author}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Fade effect at bottom */}
      <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-white to-transparent pointer-events-none"></div>

      {/* Load More Button */}
      {visibleCount < allReviews.length && (
        <div className="text-center mt-10 relative z-10">
          <button
            onClick={showMoreReviews}
            className="bg-teal-600 text-white px-5 sm:px-6 py-2 sm:py-3 rounded-md hover:bg-teal-700 transition shadow-md text-sm sm:text-base"
          >
            See More Reviews
          </button>
        </div>
      )}
    </div>
  );
};

export default CustomerReviews;
